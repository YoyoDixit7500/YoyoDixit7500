package com.example.calculater;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView result_tv, solution_tv;
    MaterialButton btn_c, btn_open_bracket, btn_close_bracket, btn_div;
    MaterialButton btn_1, btn_2, btn_3, btn_4, btn_5, btn_6, btn_7, btn_8, btn_9, btn_0;
    MaterialButton btn_mul, btn_minus, btn_plus, btn_ac, btn_equals, btn_dot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result_tv = findViewById(R.id.result_tv);
        solution_tv= findViewById(R.id.solution_tv);

        assignId(btn_c,R.id.btn_c);
        assignId(btn_ac,R.id.btn_ac);
        assignId(btn_1,R.id.btn_1);
        assignId(btn_2,R.id.btn_2);
        assignId(btn_3,R.id.btn_3);
        assignId(btn_4,R.id.btn_4);
        assignId(btn_5,R.id.btn_5);
        assignId(btn_6,R.id.btn_6);
        assignId(btn_7,R.id.btn_7);
        assignId(btn_8,R.id.btn_8);
        assignId(btn_9,R.id.btn_9);
        assignId(btn_0,R.id.btn_0);
        assignId(btn_div,R.id.btn_div);
        assignId(btn_mul,R.id.btn_mul);
        assignId(btn_minus,R.id.btn_minus);
        assignId(btn_equals,R.id.btn_equals);
        assignId(btn_plus,R.id.btn_plus);
        assignId(btn_dot,R.id.btn_dot);
        assignId(btn_open_bracket,R.id.btn_open_bracket);
        assignId(btn_close_bracket,R.id.btn_close_bracket);




    }
    void  assignId(MaterialButton btn,int id){
        btn= findViewById(id);
        btn.setOnClickListener(this);
    }

    public void onClick(View view){
        MaterialButton btn = (MaterialButton) view;
        String btnText= btn.getText().toString();
        String dataTocalculate = solution_tv.getText().toString();

        if (btnText.equals("AC")){
            solution_tv.setText("");
            result_tv.setText("0");
            return;
        }
        if (btnText.equals("=")){
            solution_tv.setText(result_tv.getText());
            return;
        }
        if (btnText.equals("C"))
        {
            dataTocalculate = dataTocalculate.substring(0,dataTocalculate.length()-1);

        }else {
            dataTocalculate = dataTocalculate + btnText;
        }
        solution_tv.setText(dataTocalculate);

        String final_result = getResult(dataTocalculate);
        if (!final_result.equals("Err"))
        {
            result_tv.setText(final_result);
        }
    }
    String getResult(String data){
        try {
            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String final_result = context.evaluateString(scriptable,data,"Javascript",1,null).toString();
            if (final_result.endsWith(".0"))
            {
                final_result = final_result.replace(".0","");
            }

            return final_result;
        }catch (Exception e ){
            return "Err";
        }

    }
}
